
from django.shortcuts import render
from .models import Book	


def home(request):
    context = {
        'book': Book.objects.all()
    }
    return render(request, 'library/home.html', context)


def about(request):
    return render(request, 'library/about.html', {'title': 'About'})

    